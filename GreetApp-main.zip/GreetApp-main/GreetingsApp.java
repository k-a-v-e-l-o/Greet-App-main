/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package greetingsapp;

import tut.ac.za.gui.GreetingsAppGUI;

/**
 *
 * @author sepit
 */
public class GreetingsApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
       new GreetingsAppGUI();
    }
    
}
