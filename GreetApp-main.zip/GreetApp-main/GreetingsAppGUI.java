/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tut.ac.za.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author sepit
 */
public class GreetingsAppGUI extends JFrame{
    
    //Panels
    private JPanel headingPnl;
    private JPanel namePnl;
    private JPanel surnamePnl;
    private JPanel nameAndSurnamePnl;
    private JPanel greetingsAreaPnl;
    private JPanel btnsPnl;
    private JPanel mainPnl;
    
    
    //Labels
    private JLabel headingLbl;
    private JLabel nameLbl;
    private JLabel surnameLbl;
  
    //TextFields
    private JTextField nameTxtFld;
    private JTextField surnameTxtFld;
    
    //textArea
    private JTextArea greetingsTxtArea;
    
    //Buttons
    private JButton greetBtn;
    private JButton clearBtn;
    private JButton exitBtn;
    
    
    public GreetingsAppGUI(){
    
        //Configuring the gui
        this.setTitle("Greetings GUI");
        this.setSize(400, 550);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBackground(Color.yellow);
        this.setResizable(true);
        
        
        //Create panels
        namePnl = new JPanel(new FlowLayout());
        surnamePnl = new JPanel(new FlowLayout());
        
        nameAndSurnamePnl = new JPanel(new GridLayout(2,1));
        greetingsAreaPnl = new JPanel(new BorderLayout());
        
        btnsPnl = new JPanel(new FlowLayout());
        mainPnl = new JPanel(new BorderLayout());
        
        headingPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headingPnl.setBorder(new BevelBorder(BevelBorder.RAISED));
        
        
        //create labels
        headingLbl = new JLabel("Greetings App");
        nameLbl = new JLabel("Name: ");
        surnameLbl = new JLabel("Surname: ");
        
        
        //create textfields
        nameTxtFld = new JTextField(20);
        surnameTxtFld = new JTextField(20);
        
        //create textarea
        greetingsTxtArea = new JTextArea(25,40);
        greetingsTxtArea.setEditable(false);
        greetingsTxtArea.setText("Hello [name] [surname]");
        
        //create buttons
        greetBtn = new JButton("Greet");
        clearBtn = new JButton("Clear");
        exitBtn = new JButton("Exit");
        
        //add namelbl and txtfld to the namepnl
        namePnl.add(nameLbl);
        namePnl.add(nameTxtFld);
        
        
        //add surnamelbl and txtfld to the surnamepnl
        surnamePnl.add(surnameLbl);
        surnamePnl.add(surnameTxtFld);
        
        
        //add the name and surnamepnl to the collective panel
        nameAndSurnamePnl.add(namePnl);
        nameAndSurnamePnl.add(surnamePnl);
        
        //add the greetingd area to its panel
        greetingsAreaPnl.add(greetingsTxtArea);
        greetingsAreaPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK,1),"Greetings Text"));
        
        
        ///add the buttons to their panel
        btnsPnl.add(greetBtn);
        btnsPnl.add(clearBtn);
        btnsPnl.add(exitBtn);
         
        
        //add functionality on the greetButton
        greetBtn.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                
                String greetV = "Hello" + "[" + nameTxtFld.getText() + "]" + "[" + surnameTxtFld.getText() + "]";
                
                greetingsTxtArea.setText(greetV);
            }
        
        });
        
        //functionality on the clear button
        clearBtn.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                
                nameTxtFld.setText("");
                surnameTxtFld.setText("");
            }
        
        });
        
        //functionality on the exit button
        exitBtn.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
                dispose();
            }
        
        });

        headingPnl.add(headingLbl);
        
        //add all the panels to the main pnl
        mainPnl.add(nameAndSurnamePnl,BorderLayout.NORTH);
        mainPnl.add(greetingsAreaPnl,BorderLayout.CENTER);
        mainPnl.add(btnsPnl,BorderLayout.SOUTH);
        
        //add all the mainpnl to the frame's pnl
        this.add(headingPnl, BorderLayout.NORTH);
        this.add(mainPnl,BorderLayout.CENTER);
       
        this.setVisible(true);
    }
   
    
    
    
}
